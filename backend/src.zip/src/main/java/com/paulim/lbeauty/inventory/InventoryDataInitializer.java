package com.paulim.lbeauty.inventory;

import com.opencsv.bean.CsvToBeanBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
@RequiredArgsConstructor
@Slf4j
public class InventoryDataInitializer implements CommandLineRunner {

    private final InventoryRepository inventoryRepository;

    @Override
    public void run(String... args) throws Exception {
        if (inventoryRepository.count() > 0) {
            log.info("Database already populated. Skipping data migration.");
            return;
        }

        log.info("Starting data migration from inventory.csv...");

        try (InputStreamReader reader = new InputStreamReader(
                new ClassPathResource("inventory.csv").getInputStream())) {

            List<InventoryCsvRecord> records = new CsvToBeanBuilder<InventoryCsvRecord>(reader)
                    .withType(InventoryCsvRecord.class)
                    .build()
                    .parse();

            Set<String> seenUpcs = new HashSet<>();

            List<Inventory> inventoryList = records.stream()
                    .filter(record -> record.getUpc() != null && !record.getUpc().trim().isEmpty())
                    .filter(record -> seenUpcs.add(record.getUpc().trim()))
                    .map(record -> {
                        Inventory item = new Inventory();
                        item.setUpc(record.getUpc().trim());
                        item.setName(record.getName());
                        item.setBrand("L-Beauty Generic");
                        item.setCategory("Uncategorized");
                        item.setDeleted(false);

                        try {
                            String priceStr = record.getPrice();
                            if (priceStr == null) {
                                item.setPrice(new BigDecimal("10.00"));
                            } else {
                                String cleanPrice = priceStr.replaceAll("[^\\d.]", "");
                                if (cleanPrice.isEmpty() || cleanPrice.equals(".")) {
                                    item.setPrice(new BigDecimal("10.00"));
                                } else {
                                    item.setPrice(new BigDecimal(cleanPrice));
                                }
                            }
                        } catch (Exception e) {
                            item.setPrice(new BigDecimal("10.00"));
                        }

                        return item;
                    }).toList();

            inventoryRepository.saveAll(inventoryList);
            log.info("Successfully imported {} unique items into the database!", inventoryList.size());

        } catch (Exception e) {
            log.error("Failed to import inventory data: ", e);
        }
    }
}